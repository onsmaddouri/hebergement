package tn.esprit.entity;

import static jdk.nashorn.internal.objects.NativeJava.type;

public class Hebergement {
    private int id ;
    private String name;
    private String descrip;
    private int prix;
    private int capacite;
    private String adresse;
    private Categorie_hebergement type; // Attribut pour stocker le type d'hébergement

    public Hebergement() {
        // Constructeur par défaut
    }

    public Hebergement(int id, String name, String descrip, int prix, int capacite, Categorie_hebergement type, String adresse) {
        this.id = id;
        this.name = name;
        this.descrip = descrip;
        this.prix = prix;
        this.capacite = capacite;
        this.adresse = adresse;
        this.type = type;
    }
     public Hebergement( String name, String descrip, int prix, int capacite, Categorie_hebergement type, String adresse) {
        this.name = name;
        this.descrip = descrip;
        this.prix = prix;
        this.capacite = capacite;
        this.adresse = adresse;
        this.type = type;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIdh(int id) {
        this.id = id;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }

    public void setType(Categorie_hebergement type) {
        this.type = type;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public int getPrix() {
        return prix;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public Categorie_hebergement getType() {
        return type;
    }

    public String getDescrip() {
        return descrip;
    }

    public int getCapacite() {
        return capacite;
    }

    // Ajoutez les getters et setters pour les attributs, y compris la catégorie

    public String getAdresse() {
        return adresse;
    }

}
