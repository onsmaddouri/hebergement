package tn.esprit.entity;

public class Categorie_hebergement {
    private int idcategorie; // Identifiant de la catégorie
    private String contenu; // Type d'hébergement

    public Categorie_hebergement() {
        // Constructeur par défaut
    }

    public Categorie_hebergement(int idcategorie, String contenu) {
        this.idcategorie = idcategorie;
        this.contenu = contenu;
    }

    public void setIdcategorie(int idcategorie) {
        this.idcategorie = idcategorie;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }

    public int getIdcategorie() {
        return idcategorie;
    }

    // Ajoutez les getters et setters pour les attributs

    public String getContenu() {
        return contenu;
    }

}
