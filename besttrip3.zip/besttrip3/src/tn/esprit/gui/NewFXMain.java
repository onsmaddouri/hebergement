package tn.esprit.gui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import static javafx.application.Application.launch;

public class NewFXMain extends Application {

    
    
    @Override
    public void start(Stage primaryStage) {
        
         
        try {
           Parent root = FXMLLoader.load(getClass().
                    getResource("Hebergement.fxml"));
            Scene scene = new Scene(root);
          primaryStage.setTitle("BestTrip");
        primaryStage.setScene(scene);
        primaryStage.show();
        } catch (IOException ex) {
           System.out.println(ex.getMessage());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}


