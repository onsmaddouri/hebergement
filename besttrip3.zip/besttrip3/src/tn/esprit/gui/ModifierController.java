package tn.esprit.gui;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import tn.esprit.entity.Hebergement;
import tn.esprit.services.HebergCRUD ;
import tn.esprit.entity.Categorie_hebergement;


// Importez les classes nécessaires pour les boîtes de dialogue JavaFX
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import tn.esprit.tools.CategorieHebergementD;

public class ModifierController implements Initializable {
    private TextField idhField;
    private TextField namehField;
    private TextField descriphField;
    private TextField prixhField;
    private TextField capacitehField;
    private TextField typehField;
    private TextField adhField;
    private Button modifierhButton;
    private Button backhbutton;
    @FXML
    private TextField idh;
    @FXML
    private TextField nameh;
    @FXML
    private TextField desch;
    @FXML
    private TextField prixh;
    @FXML
    private TextField caph;
    @FXML
    private ChoiceBox<Categorie_hebergement> typeh;

    @FXML
    private TextField adh;
    @FXML
    private Button modifierh;
    private Button backh ;
    @FXML
    private HebergCRUD HebergCRUD;
    private CategorieHebergementD categorieD;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        HebergCRUD = new HebergCRUD();
         categorieD = new CategorieHebergementD();
        // Remplissez le ChoiceBox avec les catégories
        typeh.getItems().addAll(categorieD.getCategories());
        backh.setOnAction(event -> retournerALaPagePrincipale());
    }
    

    @FXML
   private void modifierHebergement() {
    // Obtenez l'ID depuis le champ de texte
    String idText = idh.getText();
    int id = Integer.parseInt(idText);

    // Utilisez la méthode de votre classe HebergCRUD pour obtenir l'hébergement par ID
    Hebergement hebergement = HebergCRUD.getHebergementParID(id);

        
        if (hebergement != null) {
            // Récupérez les nouvelles valeurs des champs de texte
            String name = nameh.getText();
            String descrip = desch.getText();
            int prix = Integer.parseInt(prixh.getText());
            int capacite = Integer.parseInt(caph.getText());

            // Utilisez le choix de catégorie sélectionné
            Categorie_hebergement type = typeh.getValue();

            String adresse = adh.getText();

            // Mettez à jour les propriétés de l'objet Hebergement
            hebergement.setName(name);
            hebergement.setDescrip(descrip);
            hebergement.setPrix(prix);
            hebergement.setCapacite(capacite);
            hebergement.setType(type); // Utilisez le setter approprié

            hebergement.setAdresse(adresse);

            // Réinitialisez les champs de texte
            resetFields();
            showAlert(AlertType.INFORMATION, "Modification réussie", "L'hébergement a été modifié avec succès.");
        }
    }

    private void resetFields() {
        // Réinitialisez les champs de texte
        nameh.clear();
        desch.clear();
        prixh.clear();
        caph.clear();
        adh.clear();
        typeh.getSelectionModel().clearSelection();
    }

    private void showAlert(AlertType alertType, String title, String contentText) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(contentText);
        alert.showAndWait();
    }
    @FXML
private void retournerALaPagePrincipale() {
    try {
        // Chargez le fichier FXML de l'interface principale (hebergement.fxml)
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hebergement.fxml"));
        Parent root = loader.load();

        // Obtenez la scène actuelle à partir du bouton "Back"
        Scene scene = backh.getScene();

        // Remplacez le contenu de la scène actuelle par l'interface principale
        scene.setRoot(root);

        // Configurez le titre de la fenêtre (facultatif)
        Stage stage = (Stage) scene.getWindow();
        stage.setTitle("besttrip");

    } catch (IOException e) {
    }
}
}