package tn.esprit.gui;

import javafx.event.ActionEvent; // Importez la classe d'événements correcte
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button; // Importez la classe Button correcte
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HebergementController implements Initializable {

    @FXML
    private Button ajouterh;
    @FXML
    private Button modifierh;
    @FXML
    private Button supprimerh;
    @FXML
    private Button afficherh;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Initialisation du contrôleur
    }

    @FXML
    public void handleAjouterh(ActionEvent event) {
        switchToInterface("Ajouter.fxml", event);
    }

    @FXML
    public void handleModifierh(ActionEvent event) {
        switchToInterface("Modifier.fxml", event);
    }

    @FXML
    public void handleSupprimerh(ActionEvent event) {
        switchToInterface("Supprimer.fxml", event);
    }

    @FXML
    public void handleAfficherh(ActionEvent event) {
        switchToInterface("Afficher.fxml", event);
    }

    public void switchToInterface(String fxmlFileName, ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFileName));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            // Gérez l'exception de manière appropriée
        }
    }
}
