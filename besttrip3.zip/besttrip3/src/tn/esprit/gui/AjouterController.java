package tn.esprit.gui;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import tn.esprit.entity.Hebergement;
import tn.esprit.services.HebergCRUD ;
import tn.esprit.entity.Categorie_hebergement;


// Importez les classes nécessaires pour les boîtes de dialogue JavaFX
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import tn.esprit.tools.CategorieHebergementD;

public class AjouterController implements Initializable {
    private TextField idhField;
    private TextField namehField;
    private TextField descriphField;
    private TextField prixhField;
    private TextField capacitehField;
    private TextField typehField;
    private TextField adhField;
    private Button ajouterhButton;
    private Button backhbutton;
    @FXML
    private TextField idh;
    @FXML
    private TextField nameh;
    @FXML
    private TextField desch;
    @FXML
    private TextField prixh;
    @FXML
    private TextField caph;
    @FXML
    private ChoiceBox<Categorie_hebergement> typeh;

    @FXML
    private TextField adh;
    @FXML
    private Button ajouterh;
    private Button backh;
    @FXML
    private HebergCRUD HebergCRUD;
    private CategorieHebergementD categorieD;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        HebergCRUD = new HebergCRUD();
         categorieD = new CategorieHebergementD();
        // Remplissez le ChoiceBox avec les catégories
        typeh.getItems().addAll(categorieD.getCategories()); 
        backh.setOnAction(event -> retournerALaPagePrincipale());
    }

    // Méthode pour ajouter un hébergement
    @FXML
    private void ajouterHebergement() {
        // Récupérez la valeur sélectionnée dans le ChoiceBox "type"
        Categorie_hebergement type = typeh.getValue();

        // Récupérez les valeurs des autres champs
        String name = nameh.getText();
        String descrip = desch.getText();
        String prixText = prixh.getText();
        int prix = 0;
        if (!prixText.isEmpty()) {
            prix = Integer.parseInt(prixText);
        }
        String capaciteText = caph.getText();
        int capacite = 0;
        if (!capaciteText.isEmpty()) {
            capacite = Integer.parseInt(capaciteText);
        }
        String adresse = adh.getText();

        // Créez un nouvel objet Hebergement avec les valeurs
        Hebergement hebergement = new Hebergement(name, descrip, prix, capacite, type, adresse);

        // Appelez la méthode d'ajout du service CRUD
        HebergCRUD.ajouter(hebergement);

        // Réinitialisez les champs de texte et le ChoiceBox après l'ajout
        nameh.clear();
        desch.clear();
        prixh.clear();
        caph.clear();
        adh.clear();
        typeh.getSelectionModel().clearSelection();

        // Affichez une boîte de dialogue de succès ou de confirmation
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Succès");
        alert.setHeaderText(null);
        alert.setContentText("L'hébergement a été ajouté avec succès.");
        alert.showAndWait();
    }
    @FXML
    private void retournerALaPagePrincipale() {
     try {
        // Chargez le fichier FXML de l'interface principale (hebergement.fxml)
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hebergement.fxml"));
        Parent root = loader.load();

        // Obtenez la scène actuelle à partir du bouton "Back"
        Scene scene = backh.getScene();

        // Remplacez le contenu de la scène actuelle par l'interface principale
        scene.setRoot(root);

        // Configurez le titre de la fenêtre (facultatif)
        Stage stage = (Stage) scene.getWindow();
        stage.setTitle("besttrip");

    }  catch (IOException e) {
    }
}


}
