/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.esprit.gui;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import tn.esprit.entity.Categorie_hebergement;
import tn.esprit.entity.Hebergement;
import tn.esprit.services.HebergCRUD;

/**
 * FXML Controller class
 *
 * @author Ons
 */
public class SupprimerController implements Initializable {
    private TextField idhField;
     private Button supprimerhButton;
    private Button backhbutton;
    @FXML
    private TextField idh;
     @FXML
    private Button supprimerh;
    private Button backh;
   
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       backh.setOnAction(event -> retournerALaPagePrincipale());
        
    }    
    
    @FXML
   private void supprimerHebergement() {
     String idToDelete = idh.getText();

     try {
        int id = Integer.parseInt(idToDelete);
        Hebergement Hebergement;
        // Appelez la méthode de suppression de votre classe HebergCRUD
        HebergCRUD hebergCRUD = new HebergCRUD();
        hebergCRUD.supprimer(new Hebergement(id, null, null, 0, 0, (Categorie_hebergement)null, null));

        // Rafraîchissez l'affichage ici (peut-être en appelant votre méthode d'affichage à nouveau)

        // Réinitialisez le champ de texte
        idh.clear();
     } catch (NumberFormatException e) {
        // Gérez l'erreur si l'utilisateur a entré un ID non valide
        System.out.println("ID non valide : " + idToDelete);
     }
}
   @FXML
private void retournerALaPagePrincipale() {
    try {
        // Chargez le fichier FXML de l'interface principale (hebergement.fxml)
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hebergement.fxml"));
        Parent root = loader.load();

        // Obtenez la scène actuelle à partir du bouton "Back"
        Scene scene = backh.getScene();

        // Remplacez le contenu de la scène actuelle par l'interface principale
        scene.setRoot(root);

        // Configurez le titre de la fenêtre (facultatif)
        Stage stage = (Stage) scene.getWindow();
        stage.setTitle("besttrip");

    } catch (IOException e) {
    }
}

}
