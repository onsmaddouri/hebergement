package tn.esprit.gui;

import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.stage.Stage;
import tn.esprit.entity.Hebergement;
import tn.esprit.services.HebergCRUD;


public class AfficherController implements Initializable {
    private Button afficherhButton;
    private Button backhhbutton;
    @FXML
    private Button afficherh;
    private Button backh;
    @FXML
    private ListView<Hebergement> hebergementListView;

    private HebergCRUD HebergCRUD;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        HebergCRUD = new HebergCRUD();
        afficherHebergements();
        backh.setOnAction(event -> retournerALaPagePrincipale());
    }
    @FXML
    

    private void afficherHebergements() {
        List<Hebergement> hebergements = HebergCRUD.afficher();

        ObservableList<Hebergement> hebergementList = FXCollections.observableArrayList(hebergements);

        hebergementListView.setItems(hebergementList);

        // Personnalisez la façon dont les éléments d'hébergement sont affichés dans le ListView
        hebergementListView.setCellFactory(param -> new ListCell<Hebergement>() {
            @Override
            protected void updateItem(Hebergement item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText("ID : " + item.getId() + " - Nom : " + item.getName() + " - Description : " + item.getDescrip()
                            + " - Prix : " + item.getPrix() + " - Capacité : " + item.getCapacite()
                            + " - Type : " + item.getType() + " - Adresse : " + item.getAdresse());
                }
            }
        });
    }
    @FXML
private void retournerALaPagePrincipale() {
    try {
        // Chargez le fichier FXML de l'interface principale (hebergement.fxml)
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hebergement.fxml"));
        Parent root = loader.load();

        // Obtenez la scène actuelle à partir du bouton "Back"
        Scene scene = backh.getScene();

        // Remplacez le contenu de la scène actuelle par l'interface principale
        scene.setRoot(root);

        // Configurez le titre de la fenêtre (facultatif)
        Stage stage = (Stage) scene.getWindow();
        stage.setTitle("besttrip");

    } catch (IOException e) {
    }
}

}


    

