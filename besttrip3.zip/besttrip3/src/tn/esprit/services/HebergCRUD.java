/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.esprit.services;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import tn.esprit.entity.Categorie_hebergement;
import tn.esprit.entity.Hebergement;
import tn.esprit.tools.MyDB;

/**
 *
 * @author Ons
 */
public class HebergCRUD implements IService<Hebergement> {
    Connection con;
    Statement ste;
   
   
    public HebergCRUD() {
    con = MyDB.getinstance().getCon();
}
   
   
    @Override
    public void ajouter(Hebergement t) {
    try {
        String req = "INSERT INTO hebergement(name, descrip, prix, capacite, type, adresse) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement pre = con.prepareStatement(req);
        pre.setString(1, t.getName());
        pre.setString(2, t.getDescrip()); // Utilisez la méthode getDescrip() au lieu de getdescrip()
        pre.setInt(3, t.getPrix());
        pre.setInt(4, t.getCapacite());
        pre.setString(5, t.getType().getContenu());
        pre.setString(6, t.getAdresse());

        pre.executeUpdate();
    } catch (SQLException ex) {
        System.out.println(ex);
    }
}
    @Override
    public void supprimer(Hebergement t) {
       try {
            String req = "DELETE FROM Hebergement WHERE id=?";
            PreparedStatement pre = con.prepareStatement(req);
            pre.setLong(1, t.getId());
            pre.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(ex);
        } //To change body of generated methods, choose Tools | Templates.
    }


    public Hebergement getHebergementParID(int i) {
        Hebergement hebergement = null;
        String sql = "SELECT * FROM hebergement WHERE id = ?";
        Categorie_hebergement categoriehebergement = null ;

        try (PreparedStatement preparedStatement = con.prepareStatement(sql)) {
            preparedStatement.setInt(1, i);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                String descrip = resultSet.getString("descrip");
                int prix = resultSet.getInt("prix");
                int capacite = resultSet.getInt("capacite");
                int type = resultSet.getInt("type");
                String adresse = resultSet.getString("adresse");
                String sql2 = "SELECT * FROM Categorie_Hebergement WHERE idcategorie = type";
                   int idcategorie = resultSet.getInt("type");
                String contenu = resultSet.getString("descrip");
                  categoriehebergement = new Categorie_hebergement((int) id, contenu);
                

                hebergement = new Hebergement((int) id, name, descrip, prix, capacite, categoriehebergement, adresse);
            }
        } catch (SQLException ex) {
            System.out.println("Error retrieving data by ID from the database: " + ex.getMessage());
        }

        return hebergement;
    }
    @Override
    public void modifier(Hebergement hebergement) {
    // No need to declare a new HebergCRUD object here, use the class-level HebergCRUD

      try {
        // First, retrieve the existing Hebergement object by its ID
        Hebergement existingHebergement = getHebergementParID(hebergement.getId());

        if (existingHebergement != null) {
            // Make the necessary changes to the existing Hebergement object
            existingHebergement.setName(hebergement.getName());
            existingHebergement.setDescrip(hebergement.getDescrip());
            existingHebergement.setPrix(hebergement.getPrix());
            existingHebergement.setCapacite(hebergement.getCapacite());
            existingHebergement.setType(hebergement.getType());
            existingHebergement.setAdresse(hebergement.getAdresse());

            // Now, update the database with the modified data
            String req = "UPDATE Hebergement SET name=?, descrip=?, prix=?, capacite=?, type=?, adresse=? WHERE id=?";
            try (PreparedStatement preparedStatement = con.prepareStatement(req)) {
                // Set the parameter values using the existingHebergement object
                preparedStatement.setString(1, existingHebergement.getName());
                preparedStatement.setString(2, existingHebergement.getDescrip());
                preparedStatement.setInt(3, existingHebergement.getPrix());
                preparedStatement.setInt(4, existingHebergement.getCapacite());
                preparedStatement.setString(5, existingHebergement.getType().toString());
                preparedStatement.setString(6, existingHebergement.getAdresse());
                preparedStatement.setInt(7, existingHebergement.getId());

                // Execute the update
                preparedStatement.executeUpdate();
            }
        } else {
            System.out.println("Hebergement not found for the given ID.");
        }
    } catch (SQLException ex) {
        System.out.println("Error updating Hebergement: " + ex.getMessage());
    }
}



   


    

    @Override
  public List<Hebergement> afficher() {
    List<Hebergement> hebergements = new ArrayList<>();
    String sql = "SELECT * FROM hebergement";
    Categorie_hebergement categoriehebergement = null ;

    
    try (java.sql.Statement stmt = con.createStatement(); // Use try-with-resources
         ResultSet resultSet = stmt.executeQuery(sql)) {
        while (resultSet.next()) {
            long id = resultSet.getLong("id");
            String name = resultSet.getString("name");
            String descrip = resultSet.getString("descrip");
            int prix = resultSet.getInt("prix");
            int capacite = resultSet.getInt("capacite");
            String sql2 = "SELECT * FROM Categorie_Hebergement WHERE idcategorie = type";
                   int idcategorie = resultSet.getInt("type");
                  String contenu = resultSet.getString("descrip");
                  categoriehebergement = new Categorie_hebergement((int) id, contenu);
            String adresse = resultSet.getString("adresse");

            Hebergement hebergement = new Hebergement((int) id, name, descrip, prix, capacite, categoriehebergement , adresse);
            hebergements.add(hebergement);
        }
    } catch (SQLException ex) {
        System.out.println("Error retrieving data from the database: " + ex.getMessage());
    }
    
    return hebergements;
}

}

   





