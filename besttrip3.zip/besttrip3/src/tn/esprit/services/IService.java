/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.esprit.services;

import java.util.List;


/**
 *
 * @author balia
 * @param <T>
 */
public interface IService<T> {
    void ajouter(T t);
    void supprimer(T t);
    void modifier(T t); // Ajout du paramètre de type générique
    List<T> afficher();
}

