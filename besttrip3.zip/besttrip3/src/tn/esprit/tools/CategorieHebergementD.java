package tn.esprit.tools; // Vous pouvez placer cette classe dans le même package

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import tn.esprit.entity.Categorie_hebergement ;
public class CategorieHebergementD {

    /**
     *
     * @return
     */
    public List<Categorie_hebergement> getCategories() {
        List<Categorie_hebergement> categories = new ArrayList<>();
        Connection con = MyDB.getinstance().getCon();

        try {
            String query = "SELECT idcategorie, contenu FROM categorie_hebergement";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                int idcategorie = rs.getInt("idcategorie");
                String contenu = rs.getString("contenu");
                Categorie_hebergement categorie = new Categorie_hebergement(idcategorie, contenu);
                categories.add(categorie);
            }
        } catch (SQLException e) {
        }

        return categories;
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
*/